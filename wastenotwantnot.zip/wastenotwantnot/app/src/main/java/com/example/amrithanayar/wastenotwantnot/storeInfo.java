package com.example.amrithanayar.wastenotwantnot;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ShareActionProvider;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;


public class storeInfo extends AppCompatActivity{
 Cursor mCurr;
 Cursor menuCur;
 Cursor imagecurr;
 myContentProvider mcp;
 String[] selectionargs;
 double latitude;
 double longitude;
 double storeLatitude;
 double storeLongitude;
 Button button;
 double storeDistance;
    String[] strdata;
ImageView imageloc;
    MenuItem item;
private android.support.v7.widget.ShareActionProvider mShareActionProvider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){ // changes the layout if the user is using the phoen horizontally
            setContentView(R.layout.infohoriz);
        }
        else {
            setContentView(R.layout.activity_store_info);
        }

        TextView store = (TextView) findViewById(R.id.storeLabel);
        imageloc = (ImageView) findViewById(R.id.image12);
        TextView item = (TextView) findViewById(R.id.itemLabel);
        TextView price = (TextView) findViewById(R.id.priceLabel);
        TextView telephone = (TextView) findViewById(R.id.telephoneLabel);
        TextView recyclability = (TextView) findViewById(R.id.recyclabilityLabel);
        TextView far = (TextView) findViewById(R.id.distance);
        TextView mon = (TextView) findViewById(R.id.monday);
        TextView tue = (TextView) findViewById(R.id.tuesday);
        TextView wed = (TextView) findViewById(R.id.wednesday);
        TextView thur = (TextView) findViewById(R.id.thursday);
        TextView fri = (TextView) findViewById(R.id.friday);
        TextView sat = (TextView) findViewById(R.id.saturday);
        TextView sun = (TextView) findViewById(R.id.sunday);
        Intent intent = this.getIntent();
        if(intent != null){
            strdata = intent.getExtras().getStringArray("senddata");// get the store the user chose to look at

           double[] location = intent.getExtras().getDoubleArray("locationPass"); //get the user's current location
            latitude = location[0];
            longitude = location[1];

        }

        mCurr = getContentResolver().query(mcp.CONTENT_URI,null,"products",strdata,null);//query for the information required
        if(mCurr!=null){
            mCurr.moveToFirst();
            String answer = mCurr.getString(2);
            storeLatitude =mCurr.getDouble(4);
            storeLongitude = mCurr.getDouble(3);
            storeDistance = getDistance(latitude,longitude,storeLatitude,storeLatitude);
            far.setText(answer+" is "+ storeDistance+" Km away from your current location");
            //System.out.println(storeLatitude);
            store.setText(answer);
            item.setText(mCurr.getString(0));
            price.setText("£"+mCurr.getString(1));
            telephone.setText("For further information directly from " +answer+" please call: "+mCurr.getString(7));
            recyclability.setText(mCurr.getString(5) + " % recyclable");
        }
        else{
            System.out.println("sometting wrong");
        }
        String[] getim = new String[1];
        getim[0] = strdata[1];

        imagecurr = getContentResolver().query(mcp.CONTENT_URI,null,"images",getim,null); //query for the image of this store
        imagecurr.moveToFirst();
        if(imagecurr!=null){
            byte[] image = imagecurr.getBlob(0);
            Bitmap bmp = BitmapFactory.decodeByteArray(image,0,image.length);
            imageloc.setImageBitmap(bmp);

        }
        Cursor timeCur = getContentResolver().query(mcp.CONTENT_URI,null,"hours", getim,null); //query for opening times
        timeCur.moveToFirst();
        if(timeCur!=null){
            mon.setText(timeCur.getString(3)+ " - "+  timeCur.getString(4));
            timeCur.moveToNext();
            tue.setText(timeCur.getString(3)+ " - " + timeCur.getString(4));
            timeCur.moveToNext();
            wed.setText(timeCur.getString(3)+ " - " + timeCur.getString(4));
            timeCur.moveToNext();
            thur.setText(timeCur.getString(3)+ " - " + timeCur.getString(4));
            timeCur.moveToNext();
            fri.setText(timeCur.getString(3)+ " - " + timeCur.getString(4));
            timeCur.moveToNext();
            sat.setText(timeCur.getString(3)+ " - " + timeCur.getString(4));
            timeCur.moveToNext();
            sun.setText(timeCur.getString(3)+ " - " + timeCur.getString(4));

        }

button = (Button) findViewById(R.id.button); //button to get directions for user
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);

                Uri gmmIntentUri = Uri.parse("geo:"+storeLatitude + "," + storeLongitude+"?q="+storeLatitude+","+storeLongitude); //appending the coordinates creates a marker when google maps is opened
                Intent mapIntent = new Intent(Intent.ACTION_VIEW,gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if(mapIntent.resolveActivity(getPackageManager()) != null){
                    startActivity(mapIntent);
                }
            }
        });
    }
@Override
    public boolean onCreateOptionsMenu(Menu menu){ //shareActionProvider
        getMenuInflater().inflate(R.menu.share, menu);
    item = menu.findItem(R.id.menu_share);
    mShareActionProvider = (android.support.v7.widget.ShareActionProvider) MenuItemCompat.getActionProvider(item);
   setShareIntent();

    return true;
}
private void setShareIntent(){
        Cursor shareCur = getData();
        double sharelat = shareCur.getDouble(4);
        double sharelong = shareCur.getDouble(3);
        String uri = "http://maps.google.com/maps?saddr=" + sharelat + "," + sharelong +"?q=" + sharelat + ","+ sharelong; //allows user to share the link to the directions

    Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("plain/Text");
        intent.putExtra(Intent.EXTRA_TEXT,uri);

        mShareActionProvider.setShareIntent(intent);

}
@Override
public boolean onOptionsItemSelected(MenuItem menu){

    return super.onOptionsItemSelected(menu);
}
private Cursor getData(){
        Cursor currr;
    Intent intent = this.getIntent();
    if(intent != null){
        strdata = intent.getExtras().getStringArray("senddata");

        double[] location = intent.getExtras().getDoubleArray("locationPass");
        latitude = location[0];
        longitude = location[1];

        //selectionargs[0]= strdata[0];
        //selectionargs[1]=strdata[1];
    }

    currr = getContentResolver().query(mcp.CONTENT_URI,null,"products",strdata,null);
    if(currr!=null){
        currr.moveToFirst();
        String answer = currr.getString(2);

    }
    return currr;
}
public double getDistance(double homeLat, double homeLong, double storeLat,double storeLong){ //functions to find distance between two coordinates
    double theta = homeLong - storeLong;
    double dist = Math.sin(deg2rad(homeLat)) * Math.sin(deg2rad(storeLat)) + Math.cos(deg2rad(homeLat)) * Math.cos(deg2rad(storeLat)) * Math.cos(deg2rad(theta));
    dist = Math.acos(dist);
    dist = rad2deg(dist);
    dist=dist* 60 *1.1515;
    dist = dist * 1.609344;
    dist = dist*100;
    dist= Math.round(dist);
    dist = dist /100;
    return dist;
}

    private static double rad2deg(double rad) {
        return (rad * 180 / Math.PI);
    }
    private static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }


}
