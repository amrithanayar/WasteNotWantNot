package com.example.amrithanayar.wastenotwantnot;

import android.Manifest;
import android.app.LoaderManager;
import android.app.SearchManager;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainActivity extends AppCompatActivity implements LocationListener, LoaderManager.LoaderCallbacks<Cursor> { //home activity
    private ActionBar actionBar;
    private TextView textView;
    private LocationManager locationManager;
    private FusedLocationProviderClient client;
    private GestureDetectorCompat detector;
    private Boolean searchedBefore = false;
    float x1, x2, y1, y2;
    SimpleCursorAdapter adapter;
    myCursorAdapter adapter2;
    String searched = "null";
    private ListView list;
    double longitude;
    double latitude;
    String city = null;
    Button changeLocation;
     TextView itemHeader;
     TextView storeHeader;
     TextView recyclHeader;
     TextView distanceHeader;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list = (ListView) findViewById(R.id.list_item);

        if(savedInstanceState !=null){ //if there is a saved instance i.e if the app changed configuration
            searched = savedInstanceState.getString(GET_SEARCH); //get the most recent search string


            func(); //make sure the search results that were originally displayed are displayed again
        }


        requestPermission(); //request location permissions
        getLocation(); //get the location
        changeLocation = (Button) findViewById(R.id.changeLocation); //again incorrectly names this is the USER GUIDE BUTTON
        changeLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent myIntent = new Intent(MainActivity.this,locationPicker.class); //onclick new activity containing user guide is started
                startActivity(myIntent);
            }
        });
        ;
        itemHeader=(TextView) findViewById(R.id.textView9);
        storeHeader=(TextView) findViewById(R.id.textView8);
        recyclHeader=(TextView) findViewById(R.id.textView10);
        distanceHeader=(TextView) findViewById(R.id.textView11);

    }
    private static final String GET_SEARCH = MainActivity.class.getName() + ".searchString";
@Override
protected void onSaveInstanceState(Bundle outState){ //if the configuration changes and onDestroy is called
        super.onSaveInstanceState(outState);
        if(searched!=null) {
            outState.putSerializable(GET_SEARCH, searched); //save the search string
        }

}
@Override
protected void onRestoreInstanceState(Bundle bundle){//once restored
    super.onRestoreInstanceState(bundle);
    searched = (String) bundle.getSerializable(GET_SEARCH);//make sure the class knows the previous search string
}

    private void requestPermission() { //request location permission
        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, 1);
        getLocation();
    }

    private void getLocation() { //get location of user

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        client = LocationServices.getFusedLocationProviderClient(this);
        if(ActivityCompat.checkSelfPermission(MainActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //TODO: Consider calling
            //            //    ActivityCompat#requestPermissions
            //            // here to request the missing permissions, and then overriding
            //            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //            //                                          int[] grantResults)
            //            // to handle the case where the user grants the permission. See the documentation
            //            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        client.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {//get the user's last known location

                String city = null;
                if(location!=null){ //make sure location is not displayed if the user has not had a past location

                     latitude = location.getLatitude();
                     longitude = location.getLongitude();
                    try {
                        city = getCity(latitude,longitude);
                    } catch(IOException e) {
                        e.printStackTrace();
                    }

                    TextView textView = findViewById(R.id.locationtxt);
                    textView.setText(city);

                }


            }
        });


        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000, 0 , (LocationListener) this);// make sure the application updates the location in intervals

    }
    private String getCity(double latitude, double longitude) throws IOException { //convert the location coordinates to an actual address to display
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses = geocoder.getFromLocation(latitude,longitude,1);
        String cityName = addresses.get(0).getAddressLine(0);

        return cityName;

    }

    @Override
    public void onLocationChanged(Location location) { //when location changes make sure this is displayed

        latitude = location.getLatitude();
        longitude = location.getLongitude();
        try {
            city = getCity(latitude,longitude);
        } catch (IOException e) {
            e.printStackTrace();
        }

        TextView textView = findViewById(R.id.locationtxt);
        textView.setText(city);


    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){ //adding search to action bar
       MenuInflater inflater = getMenuInflater();
       inflater.inflate(R.menu.menu_search,menu);
        //list = (ListView) findViewById(R.id.list_item);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.menuSearch).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));

        searchView.setSubmitButtonEnabled(true);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                searched = "%" + query + "%"; //so that the SQL string that is put togther in the cursor adapter is searching for anything containing the string

                func();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
            itemHeader.setText("Item"); //creates the labels that are static
            storeHeader.setText("Store");
            recyclHeader.setText("Recyclability");
            distanceHeader.setText("Distance");


                searched = "%" +newText + "%";

                func();
                return false;
            }
        });

       return true;
    }
    public void func (){// function to initiate the loader
        if(searchedBefore==false){
            getLoaderManager().initLoader(1,null,this);// if there has not been a search before
        }
        else{
            getLoaderManager().restartLoader(0,null,this);//if there has been a search before restart
        }

       // adapter = new SimpleCursorAdapter(getApplicationContext(),R.layout.activity_main,null,null,null);
    }
    public boolean onTouchEvent(MotionEvent touchevent){ //the touch event responsible for the swipe up action

        switch (touchevent.getAction()){
            case MotionEvent.ACTION_DOWN:
                x1 = touchevent.getX();
                y1 = touchevent.getY();
                break;
            case MotionEvent.ACTION_UP: //when the action is up
                x2 = touchevent.getX(); //coordinates
                y2 = touchevent.getY(); //coordinates
                if(y1 > y2) { //checks the action was an upward swi[e

                    Intent i = new Intent(MainActivity.this, furtherInfo.class); //starts new static activity
                    startActivity(i);
                }
                break;

        }
        return false;

    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) { //starts loader



        String[] srt =  new String[1];
        srt[0] = searched;
        Uri myUri = myContentProvider.CONTENT_URI;

        String[] proj = {"item", "price","store","longitude","latitude","recyclability","telephone"};

        return new CursorLoader(this, myUri,proj,"products",srt,"recyclability"); //queries the data base
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, final Cursor data) { //once data is loaded


        String[] Columns = new String[]{
                "item",
                "price",
                "store"
        };


    if(searchedBefore==false) { //if there are no current results


        data.moveToFirst();
        if (data != null) {
            data.moveToFirst();
            String pl = data.getString(0);

            adapter2 = new myCursorAdapter(this, data); //new adapter
            adapter2.passCoord(latitude,longitude); //pass the coordinates of user's current location so distance can be calculated

            list.setAdapter(adapter2); //set the adapter to populate the list
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //setting onclick events for each item of the list

                    Intent myIntent = new Intent(view.getContext(), storeInfo.class);
                    data.moveToFirst();
                    String[] pass = new String[2];
                    //nect if statement and for loop iterate through cursor results to see which item was clicked and get that store's coordinates

                    if (position == 0) {
                        pass[0] = data.getString(0);
                        pass[1] = data.getString(2);
                    }
                    for (int i = 0; i < position; i++) {
                        data.moveToNext();
                        pass[0] = data.getString(0);
                        pass[1] = data.getString(2);

                    }
                    double[] passdis = {latitude, longitude}; //passes coordinates to the new activity
                    myIntent.putExtra("senddata", pass); //passes the store
                    myIntent.putExtra("locationPass", passdis);//pases the coordinates
                    startActivityForResult(myIntent, 0); //starts the new activity
                }
            });
        }
        searchedBefore=true; //set the searchedBefore boolean to true
    }
    else{
        adapter2.passCoord(latitude,longitude);
        data.moveToFirst();
        if(data!=null)
        {
           ;
            adapter2.notifyDataSetChanged();//change the adapter's data set according to search
            adapter2.swapCursor(data);//change the adapter's data set according to search
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //set the same onclick listener from before

                    Intent myIntent = new Intent(view.getContext(), storeInfo.class);
                    data.moveToFirst();
                    String[] pass = new String[2];

                    if (position == 0) {
                        pass[0] = data.getString(0);
                        pass[1] = data.getString(2);
                    }
                    for (int i = 0; i < position; i++) {
                        data.moveToNext();
                        pass[0] = data.getString(0);
                        pass[1] = data.getString(2);

                    }
                    double[] passdis = {latitude, longitude};
                    myIntent.putExtra("senddata", pass);
                    myIntent.putExtra("locationPass", passdis);
                    startActivityForResult(myIntent, 0);
                }
            });


        }
        else{
            System.out.println("data is null");
        }


    }




    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }


}
