package com.example.amrithanayar.wastenotwantnot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class locationPicker extends AppCompatActivity { //incorrectly named but this is the USER GUIDE
WebView userGuide;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_picker);
        userGuide = (WebView) findViewById(R.id.webview); //identifies webView
        userGuide.setWebViewClient(new WebViewClient());
        userGuide.loadUrl("file:///android_asset/userGuide/userGuide.html");//Not real url, simply the folder within the application's assets folder

    }
}
