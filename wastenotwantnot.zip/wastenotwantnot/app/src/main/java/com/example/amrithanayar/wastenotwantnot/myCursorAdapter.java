package com.example.amrithanayar.wastenotwantnot;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

public class myCursorAdapter extends CursorAdapter {

    double currentLat;
    double currentLong;

    public myCursorAdapter(Context context, Cursor c) {
        super(context, c);


    }
    public void passCoord(double lat, double longg){ //set the coordinates passed to a variable
        currentLat = lat;
        currentLong = longg;
    }


    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {

            return LayoutInflater.from(context).inflate(R.layout.rowtemplate,parent,false);



    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        if(cursor!=null) {

            //System.out.println(this.getClass().getSimpleName());
            TextView store = (TextView) view.findViewById(R.id.storeName);
            TextView itemName = (TextView) view.findViewById(R.id.itemName);
            TextView recycle = (TextView) view.findViewById(R.id.recyle);
            TextView distance = (TextView) view.findViewById(R.id.distance);
            String item = cursor.getString(0); //getting the values of each item from database
            String mPrice = cursor.getString(1);
            String mStore = cursor.getString(2);
            String recy = cursor.getString(5);
            double storeLat = cursor.getDouble(4);
            double storeLong = cursor.getDouble(3);
            double mDistance=getDistance(currentLat,currentLong,storeLat,storeLong);//fucntion to get distance between two points
            long factor = (long) Math.pow(10,2); //round distance to 2 d.p
            mDistance = mDistance*factor;
            long temp = Math.round(mDistance);
            mDistance = temp / factor;

            distance.setText(mDistance + " Km away");

            recycle.setText(recy+"%");
            itemName.setText(item);
            store.setText(mStore);

                ;
        }
        else{

        }



    }

    public void refreshEvents(Cursor cursor){
        System.out.println("refreshCursor");

    }
    public double getDistance (double latitude1,double longitude1, double latitude2, double longitude2){ //function to calculate the distance between two coordinates
        double theta = longitude1 - longitude2;
        double dist = Math.sin(deg2rad(latitude1)) * Math.sin(deg2rad(latitude2)) + Math.cos(deg2rad(latitude1)) * Math.cos(deg2rad(latitude2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist=dist* 60 *1.1515;
        dist = dist * 1.609344;
        return dist;
    }
    private static double rad2deg(double rad) {
        return (rad * 180 / Math.PI);
    }
    private static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
}
