package com.example.amrithanayar.wastenotwantnot;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.io.IOException;

public class myContentProvider extends ContentProvider { //custom content provider

    private static final String AUTHORITY = "com.example.amrithanayar.wastenotwantnot";
    private static final String BASE_PATH = "WasteNotWantNot";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + BASE_PATH);
    private SQLiteDatabase database;

    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    static {
        uriMatcher.addURI(AUTHORITY, BASE_PATH, 1);
        uriMatcher.addURI(AUTHORITY, BASE_PATH + "/#",2);
    }





    @Override
    public boolean onCreate() { //when an instance of this class is created

        dataHelper mDbHelper = new dataHelper(getContext()); //get SQLIte helper
        try {
            mDbHelper.createDatabase();
        } catch (IOException e) {
            Log.e("contentProvider",e.toString() + " Unable to create database");
            throw new Error("Unable to create database");
        }

        mDbHelper.openDataBase();
        database = mDbHelper.getReadableDatabase();//get the database to be able to be read

        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {//query the database
        Cursor mCur;
        String SqlString = null;
        if(selection=="products" && selectionArgs.length==1){ //if statements to ensure the right SQL statement is used as application queries many times for different tables depending on the activity
            SqlString = "SELECT * FROM products WHERE item LIKE ? ORDER BY ?";
        }
         else if(selection=="products" && selectionArgs.length==2){
            SqlString = "SELECT * FROM  products WHERE item LIKE ? AND store LIKE?";
        }
        else {

            SqlString = "SELECT * FROM " + selection + " WHERE store LIKE ?";
        }
        switch(uriMatcher.match(uri)) { //ensure the Uri matches
            case 1:



                mCur = database.rawQuery(SqlString, selectionArgs ); //query the data base


                break;
            default:
                throw new IllegalArgumentException("Not know Uri " + uri); //if the Uri is not known
        }
        mCur.setNotificationUri(getContext().getContentResolver(),uri);

        return mCur; //return the cursor with the data results
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
